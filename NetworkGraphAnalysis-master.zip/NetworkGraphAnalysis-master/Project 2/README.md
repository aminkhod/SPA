#Movie rating predictions on IMDb
• Generated a directed actor network and an undirected movie network based on IMDb datasets  
• Utilized pagerank algorithm on actor network to find top actors  
• Applied fast greedy Newman community detection algorithm to find top genres in movie network  
• Extracted network features and applied regression algorithms to predict movie ratings  

Technologies: R, Python, iGraph, NumPy, SciPy
